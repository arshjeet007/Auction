import { Routes } from '@angular/router';

// Import all components
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { UserRegisterComponent } from './components/user-register/user-register.component';
import { AdminRegisterComponent } from './components/admin-register/admin-register.component';
import { BuyerDashboardComponent } from './components/buyer-dashboard/buyer-dashboard.component';
import { SellerDashboardComponent } from './components/seller-dashboard/seller-dashboard.component';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { AuctionListComponent } from './components/auction-list/auction-list.component';
import { AuctionDetailComponent } from './components/auction-detail/auction-detail.component';

export const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'user-register', component: UserRegisterComponent },
  { path: 'admin-register', component: AdminRegisterComponent },
  { path: 'buyer-dashboard', component: BuyerDashboardComponent },
  { path: 'seller-dashboard', component: SellerDashboardComponent },
  { path: 'admin-dashboard', component: AdminDashboardComponent },
  { path: 'auction-list', component: AuctionListComponent },
  { path: 'auction-detail', component: AuctionDetailComponent },
  // { path: 'create-auction', component: CreateAuctionComponent },
  // { path: 'payment', component: PaymentComponent },
  // { path: 'transaction-history', component: TransactionHistoryComponent },
  // { path: 'submit-review', component: SubmitReviewComponent },
  // { path: 'review-list', component: ReviewListComponent }
];