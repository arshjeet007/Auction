export const environment = {
  production: true,
  apiUrl: 'https://api.bidhub-auctions.com/api'
};