import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Bid } from '../models/bid.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BidService {
  constructor(private http: HttpClient) {}
  
  getBidsByAuctionId(auctionId: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(`${environment.apiUrl}/bids/auction/${auctionId}`);
  }
  
  getBidsByUserId(userId: string): Observable<Bid[]> {
    return this.http.get<Bid[]>(`${environment.apiUrl}/bids/user/${userId}`);
  }
  
  placeBid(bid: { auctionId: string, amount: number }): Observable<Bid> {
    return this.http.post<Bid>(`${environment.apiUrl}/bids`, bid);
  }
  
  getHighestBid(auctionId: string): Observable<Bid> {
    return this.http.get<Bid>(`${environment.apiUrl}/bids/auction/${auctionId}/highest`);
  }
}