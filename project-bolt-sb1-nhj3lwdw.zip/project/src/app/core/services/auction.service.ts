import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Auction } from '../models/auction.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuctionService {
  constructor(private http: HttpClient) {}
  
  getAllAuctions(): Observable<Auction[]> {
    return this.http.get<Auction[]>(`${environment.apiUrl}/auctions`);
  }
  
  getAuctionById(id: string): Observable<Auction> {
    return this.http.get<Auction>(`${environment.apiUrl}/auctions/${id}`);
  }
  
  createAuction(auctionData: FormData): Observable<Auction> {
    return this.http.post<Auction>(`${environment.apiUrl}/auctions`, auctionData);
  }
  
  updateAuction(id: string, auctionData: FormData): Observable<Auction> {
    return this.http.put<Auction>(`${environment.apiUrl}/auctions/${id}`, auctionData);
  }
  
  deleteAuction(id: string): Observable<void> {
    return this.http.delete<void>(`${environment.apiUrl}/auctions/${id}`);
  }
  
  getAuctionsByCategory(categoryId: string): Observable<Auction[]> {
    return this.http.get<Auction[]>(`${environment.apiUrl}/auctions/category/${categoryId}`);
  }
  
  getAuctionsBySeller(sellerId: string): Observable<Auction[]> {
    return this.http.get<Auction[]>(`${environment.apiUrl}/auctions/seller/${sellerId}`);
  }
}