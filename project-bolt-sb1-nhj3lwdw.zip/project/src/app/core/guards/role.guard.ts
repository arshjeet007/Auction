import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    const requiredRole = route.data['role'] as string;
    
    if (this.authService.hasRole(requiredRole)) {
      return true;
    }
    
    // Redirect to appropriate dashboard based on user role
    const userRole = this.authService.getUserRole();
    if (userRole) {
      this.router.navigate([`/${userRole}`]);
    } else {
      this.router.navigate(['/home']);
    }
    
    return false;
  }
}