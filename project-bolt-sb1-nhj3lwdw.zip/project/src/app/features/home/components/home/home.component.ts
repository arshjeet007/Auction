import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  template: `
    <div class="container">
      <h1>Welcome to BidHub Auctions</h1>
      <p>Your premier destination for online auctions</p>
    </div>
  `,
  styles: [`
    h1 { color: var(--primary); }
  `],
  standalone: true,
  imports: [CommonModule]
})
export class HomeComponent {}