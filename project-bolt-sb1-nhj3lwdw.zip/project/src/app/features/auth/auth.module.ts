import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { UserRegisterComponent } from './components/user-register/user-register.component';
import { AdminRegisterComponent } from './components/admin-register/admin-register.component';

@NgModule({
  declarations: [
    LoginComponent,
    RegisterComponent,
    UserRegisterComponent,
    AdminRegisterComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    AuthRoutingModule
  ]
})
export class AuthModule { }