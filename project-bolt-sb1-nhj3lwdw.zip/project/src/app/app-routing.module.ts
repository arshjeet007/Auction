import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', loadComponent: () => import('./components/home/home.component').then(m => m.HomeComponent) },
  { path: 'login', loadComponent: () => import('./components/auth/login/login.component').then(m => m.LoginComponent) },
  { path: 'register', loadComponent: () => import('./components/auth/register/register.component').then(m => m.RegisterComponent) },
  { path: 'register/user', loadComponent: () => import('./components/auth/user-register/user-register.component').then(m => m.UserRegisterComponent) },
  { path: 'register/admin', loadComponent: () => import('./components/auth/admin-register/admin-register.component').then(m => m.AdminRegisterComponent) },
  { path: 'buyer', loadComponent: () => import('./components/dashboard/buyer-dashboard/buyer-dashboard.component').then(m => m.BuyerDashboardComponent) },
  { path: 'seller', loadComponent: () => import('./components/dashboard/seller-dashboard/seller-dashboard.component').then(m => m.SellerDashboardComponent) },
  { path: 'admin', loadComponent: () => import('./components/dashboard/admin-dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent) },
  { path: 'auctions', loadComponent: () => import('./components/auction/auction-list/auction-list.component').then(m => m.AuctionListComponent) },
  { path: 'auctions/:id', loadComponent: () => import('./components/auction/auction-detail/auction-detail.component').then(m => m.AuctionDetailComponent) },
  { path: 'create-auction', loadComponent: () => import('./components/auction/create-auction/create-auction.component').then(m => m.CreateAuctionComponent) },
  { path: 'payment', loadComponent: () => import('./components/payment/payment.component').then(m => m.PaymentComponent) },
  { path: 'transactions', loadComponent: () => import('./components/transaction-history/transaction-history.component').then(m => m.TransactionHistoryComponent) },
  { path: 'reviews/submit', loadComponent: () => import('./components/review/submit-review/submit-review.component').then(m => m.SubmitReviewComponent) },
  { path: 'reviews', loadComponent: () => import('./components/review/review-list/review-list.component').then(m => m.ReviewListComponent) },
  { path: '**', redirectTo: '/home' }
];